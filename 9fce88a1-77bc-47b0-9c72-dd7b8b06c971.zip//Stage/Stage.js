/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop2", "./Stage/costumes/backdrop2.svg", {
        x: 253.5,
        y: 189.6999969482422
      }),
      new Costume("backdrop1", "./Stage/costumes/backdrop1.svg", {
        x: 270.5,
        y: 193.774995
      })
    ];

    this.sounds = [new Sound("pop", "./Stage/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];

    this.vars.fov = 60;
    this.vars.res = 4;

    this.watchers.fov = new Watcher({
      label: "FOV",
      style: "slider",
      visible: true,
      value: () => this.vars.fov,
      setValue: value => {
        this.vars.fov = value;
      },
      step: 1,
      min: 30,
      max: 120,
      x: 240,
      y: 180
    });
    this.watchers.res = new Watcher({
      label: "RES",
      style: "slider",
      visible: true,
      value: () => this.vars.res,
      setValue: value => {
        this.vars.res = value;
      },
      step: 1,
      min: 2,
      max: 16,
      x: 584,
      y: 180
    });
  }

  *whenGreenFlagClicked() {
    this.costume = "backdrop1";
  }
}

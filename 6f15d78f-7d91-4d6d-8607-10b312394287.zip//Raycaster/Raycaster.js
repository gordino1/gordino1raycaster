/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Raycaster extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Hitbox", "./Raycaster/costumes/Hitbox.svg", { x: 2, y: 2 })
    ];

    this.sounds = [new Sound("Meow", "./Raycaster/sounds/Meow.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Raycast" },
        this.whenIReceiveRaycast
      )
    ];

    this.vars.x = 242;
    this.vars.distance = 102.26679426825;
    this.vars.height = 39.11338014084841;
    this.vars.scanLines = 120;
    this.vars.dir = 45;
  }

  *whenGreenFlagClicked() {
    this.stage.vars.res = 4;
    this.stage.vars.fov = 60;
    this.costume = "Hitbox";
    this.rotationStyle = Sprite.RotationStyle.DONT_ROTATE;
    this.effects.ghost = 100;
  }

  *singleRay() {
    this.goto(this.sprites["Player"].x, this.sprites["Player"].y);
    while (!this.touching(this.sprites["Level"].andClones())) {
      this.move(4);
    }
    while (!!this.touching(this.sprites["Level"].andClones())) {
      this.move(-0.5);
    }
    if (this.touching(this.sprites["LevelColor"].andClones())) {
      this.penColor.h = 58;
    } else {
      this.penColor.h = 53;
    }
    this.vars.distance = Math.hypot(
      this.sprites["Player"].x - this.x,
      this.sprites["Player"].y - this.y
    );
    this.vars.distance =
      this.toNumber(this.vars.distance) *
      Math.cos(this.degToRad(this.direction - this.toNumber(this.vars.dir)));
    this.penColor.v = 120 - this.toNumber(this.vars.distance) / 1.5;
    this.vars.height = 4000 / this.toNumber(this.vars.distance);
    this.goto(this.toNumber(this.vars.x), this.toNumber(this.vars.height));
    this.penDown = true;
    this.y = 0 - this.toNumber(this.vars.height);
    this.penDown = false;
  }

  *whenIReceiveRaycast() {
    this.clearPen();
    this.penSize = this.toNumber(this.stage.vars.res);
    this.penColor.h = 53;
    this.direction = this.sprites["Player"].direction;
    yield* this.raycast();
  }

  *raycast() {
    this.vars.dir = this.direction;
    this.vars.x = this.toNumber(this.stage.vars.res) / 2 - 240;
    this.direction -= this.toNumber(this.stage.vars.fov) / 2;
    this.vars.scanLines = 480 / this.toNumber(this.stage.vars.res);
    for (let i = 0; i < this.toNumber(this.vars.scanLines); i++) {
      this.warp(this.singleRay)();
      this.direction +=
        this.toNumber(this.stage.vars.fov) / this.toNumber(this.vars.scanLines);
      this.vars.x += this.toNumber(this.stage.vars.res);
    }
  }
}

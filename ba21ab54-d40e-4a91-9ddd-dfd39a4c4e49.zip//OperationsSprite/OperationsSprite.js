/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class OperationsSprite extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./OperationsSprite/costumes/costume1.svg", {
        x: 0,
        y: 0
      })
    ];

    this.sounds = [
      new Sound("pop", "./OperationsSprite/sounds/pop.wav"),
      new Sound(
        "Get Them Before They Get You",
        "./OperationsSprite/sounds/Get Them Before They Get You.mp3"
      )
    ];

    this.triggers = [
      new Trigger(Trigger.KEY_PRESSED, { key: "o" }, this.whenKeyOPressed),
      new Trigger(Trigger.KEY_PRESSED, { key: "p" }, this.whenKeyPPressed),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2)
    ];
  }

  *whenKeyOPressed() {
    this.stage.watchers.fov.visible = false;
    this.stage.watchers.res.visible = false;
  }

  *whenKeyPPressed() {
    this.stage.watchers.fov.visible = true;
    this.stage.watchers.res.visible = true;
  }

  *whenGreenFlagClicked() {
    this.stage.watchers.fov.visible = true;
    this.stage.watchers.res.visible = true;
  }

  *whenGreenFlagClicked2() {
    while (true) {
      yield* this.playSoundUntilDone("Get Them Before They Get You");
      yield;
    }
  }
}

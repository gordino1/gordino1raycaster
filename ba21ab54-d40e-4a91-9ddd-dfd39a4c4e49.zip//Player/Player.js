/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Player extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Player", "./Player/costumes/Player.svg", {
        x: 4.03846153846149,
        y: 4.0183924762802405
      }),
      new Costume("Hitbox", "./Player/costumes/Hitbox.svg", { x: 2, y: 2 })
    ];

    this.sounds = [new Sound("Meow", "./Player/sounds/Meow.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenGreenFlagClicked() {
    this.goto(0, 0);
    this.rotationStyle = Sprite.RotationStyle.ALL_AROUND;
    this.direction = 45;
    this.costume = "Player";
    this.effects.ghost = 100;
    while (true) {
      if (this.keyPressed("left arrow")) {
        this.direction -= 3;
      }
      if (this.keyPressed("right arrow")) {
        this.direction += 3;
      }
      if (this.keyPressed("up arrow") || this.keyPressed("w")) {
        yield* this.move2(2);
      }
      if (this.keyPressed("down arrow") || this.keyPressed("s")) {
        yield* this.move2(-2);
      }
      if (this.keyPressed("a")) {
        this.direction -= 90;
        yield* this.move2(2);
        this.direction += 90;
      }
      if (this.keyPressed("d")) {
        this.direction += 90;
        yield* this.move2(2);
        this.direction -= 90;
      }
      this.broadcast("Raycast");
      yield;
    }
  }

  *move2(steps) {
    this.costume = "Hitbox";
    this.rotationStyle = Sprite.RotationStyle.DONT_ROTATE;
    yield* this.tryMove(
      this.toNumber(steps) * Math.sin(this.degToRad(this.direction)),
      0
    );
    yield* this.tryMove(
      0,
      this.toNumber(steps) * Math.cos(this.degToRad(this.direction))
    );
    this.costume = "Player";
    this.rotationStyle = Sprite.RotationStyle.ALL_AROUND;
  }

  *tryMove(dx, dy) {
    this.x += this.toNumber(dx);
    this.y += this.toNumber(dy);
    if (this.touching(this.sprites["Level"].andClones())) {
      this.x += 0 - this.toNumber(dx);
      this.y += 0 - this.toNumber(dy);
    }
  }
}
